﻿using WildFarm.Core;

Engine engine = new Engine();
engine.Run();