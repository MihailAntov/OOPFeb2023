﻿namespace Vehicles.Models.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}