﻿using System;
namespace CustomStack
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
           
        }
    }
}