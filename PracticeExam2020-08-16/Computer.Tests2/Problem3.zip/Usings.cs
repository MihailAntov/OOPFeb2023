global using NUnit.Framework;
global using Computers;