﻿using System;

namespace MilitaryElite.Models
{
    public interface IPrivate
    {
        Decimal Salary { get; }
    }
}
