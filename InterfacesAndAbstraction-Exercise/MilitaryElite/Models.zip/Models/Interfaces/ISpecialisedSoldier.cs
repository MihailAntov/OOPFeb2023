﻿namespace MilitaryElite.Models
{
    public interface ISpecialisedSoldier
    {
        string Corps { get; }

    }
}
