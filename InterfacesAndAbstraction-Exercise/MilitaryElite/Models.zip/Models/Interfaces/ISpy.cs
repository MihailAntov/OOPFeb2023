﻿namespace MilitaryElite.Models
{
    public interface ISpy
    {
        public int CodeNumber { get; }
    }
}
