﻿using System.Collections.Generic;

namespace MilitaryElite.Models
{
    public interface ILieutenantGeneral
    {
        List<Private> Privates { get; }
    }

}


