﻿

namespace PersonInfo
{
    public class Citizen : IPerson
    {
        private int age;
        private string name;
        public Citizen(string name, int age)
        {
            Name = name;
            Age = age;
        }
        public string Name { get { return name; } private set { name = value; } }

        public int Age { get { return age; } private set { age = value; } }

    }
}
