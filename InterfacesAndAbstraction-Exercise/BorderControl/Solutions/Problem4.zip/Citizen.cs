﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BorderControl
{
    public class Citizen : ICheckable
    {
        public Citizen(string name, int age, string id)
        {
            Name = name;
            Age = age;
            Id = id;
        }

        public string Name { get; set; }
        public int Age { get; set; }
        public string Id { get; set; }

        public string Credentials =>  Id;

        public bool CheckId(string lastDigits)
        {
            int checkLength = lastDigits.Length;

            string currentLastDigits = string.Join("",Id.TakeLast(checkLength));
            return currentLastDigits == lastDigits;
        }
    }
}
