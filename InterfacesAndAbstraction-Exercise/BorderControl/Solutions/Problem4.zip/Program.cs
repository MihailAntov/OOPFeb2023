﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BorderControl
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string input;
            List<ICheckable> entries = new List<ICheckable>();

            while((input = Console.ReadLine()) != "End")
            {
                string[] entryArgs = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if(entryArgs.Length == 3)
                {
                    string name = entryArgs[0];
                    int age = int.Parse(entryArgs[1]);
                    string id = entryArgs[2];
                    entries.Add(new Citizen(name, age, id));
                }
                else if (entryArgs.Length == 2)
                {
                    string model = entryArgs[0];
                    string serialNumber = entryArgs[1];
                    entries.Add(new Robot(model, serialNumber));
                }
            }

            string lastDigits = Console.ReadLine();

            foreach(ICheckable entry in entries.Where(e=>e.CheckId(lastDigits)))
            {
                Console.WriteLine(entry.Credentials);
            }
        }
    }
}