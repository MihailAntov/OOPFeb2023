﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
namespace BorderControl
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string input;
            List<IBirthable> entries = new List<IBirthable>();

            while((input = Console.ReadLine()) != "End")
            {
                string[] entryArgs = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if(entryArgs.Length == 5)
                {
                    string name = entryArgs[1];
                    int age = int.Parse(entryArgs[2]);
                    string id = entryArgs[3];
                    DateTime birthdate = DateTime.ParseExact(entryArgs[4],"dd/MM/yyyy",CultureInfo.InvariantCulture);
                    entries.Add(new Citizen(name, age, id,birthdate));
                }
                else if (entryArgs[0] == "Pet")
                {
                    string name = entryArgs[1];
                    DateTime birthdate = DateTime.ParseExact(entryArgs[2],"dd/MM/yyyy",CultureInfo.InvariantCulture);
                    entries.Add(new Pet(name, birthdate));
                }
                //else
                //{
                //    string model = entryArgs[1];
                //    string serialNumber = entryArgs[2];
                    
                //}
            }

            int targetYear = int.Parse(Console.ReadLine());

            foreach(IBirthable entry in entries.Where(e=>e.Birthdate.Year == targetYear))
            {
                Console.WriteLine(entry.Birthdate.ToString("dd/MM/yyyy"));
            }
        }
    }
}